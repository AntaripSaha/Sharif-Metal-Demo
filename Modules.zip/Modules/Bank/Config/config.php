<?php

return [
    'name' => 'Bank'
];
