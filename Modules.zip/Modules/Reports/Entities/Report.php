<?php

namespace Modules\Reports\Entities;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $fillable = [];
}
