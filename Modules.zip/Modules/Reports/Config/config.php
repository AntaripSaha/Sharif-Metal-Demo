<?php

return [
    'name' => 'Reports'
];
