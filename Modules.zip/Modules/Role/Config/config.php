<?php

return [
    'name' => 'Role'
];
