<?php

return [
    'name' => 'Module'
];
