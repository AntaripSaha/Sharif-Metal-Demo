<?php

namespace Modules\ActivityLog\Entities;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    protected $fillable = [];
}
