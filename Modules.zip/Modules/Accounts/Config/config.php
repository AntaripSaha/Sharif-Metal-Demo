<?php

return [
    'name' => 'Accounts'
];
