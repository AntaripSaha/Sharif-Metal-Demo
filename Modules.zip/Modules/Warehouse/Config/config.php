<?php

return [
    'name' => 'Warehouse'
];
